print 'Hello! world!'
